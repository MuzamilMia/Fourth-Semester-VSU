﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Doll_Managment_Project
{
    public enum SparkleShape
    {
        Diamond,
        Circle,
        Heart
    }
    public static class SparkleColor
    {
        public static readonly Color Pink = Color.FromArgb(255, 182, 193);
    }
}
