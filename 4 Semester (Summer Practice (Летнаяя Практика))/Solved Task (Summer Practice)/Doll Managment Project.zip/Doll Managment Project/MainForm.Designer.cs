﻿namespace Doll_Managment_Project
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.btnShirtColor = new System.Windows.Forms.Button();
            this.btnPantColor = new System.Windows.Forms.Button();
            this.comboFacewear = new System.Windows.Forms.ComboBox();
            this.colorDialog = new System.Windows.Forms.ColorDialog();
            this.btnDeleteRhinestones = new System.Windows.Forms.Button();
            this.btnsunglasses = new System.Windows.Forms.Button();
            this.btnglasses = new System.Windows.Forms.Button();
            this.btnfacewear = new System.Windows.Forms.Button();
            this.btnhockymask = new System.Windows.Forms.Button();
            this.btncap = new System.Windows.Forms.Button();
            this.btnskimask = new System.Windows.Forms.Button();
            this.btnnone = new System.Windows.Forms.Button();
            this.pictureBox10 = new System.Windows.Forms.PictureBox();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btnexit = new System.Windows.Forms.Button();
            this.pictureBox = new System.Windows.Forms.PictureBox();
            this.pictureBox11 = new System.Windows.Forms.PictureBox();
            this.cmboSparkle = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).BeginInit();
            this.SuspendLayout();
            // 
            // btnShirtColor
            // 
            this.btnShirtColor.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.btnShirtColor.Font = new System.Drawing.Font("Microsoft YaHei", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnShirtColor.Location = new System.Drawing.Point(662, 39);
            this.btnShirtColor.Name = "btnShirtColor";
            this.btnShirtColor.Size = new System.Drawing.Size(128, 51);
            this.btnShirtColor.TabIndex = 1;
            this.btnShirtColor.Text = "Shirt Color";
            this.btnShirtColor.UseVisualStyleBackColor = false;
            this.btnShirtColor.Click += new System.EventHandler(this.btnShirtColor_Click_1);
            // 
            // btnPantColor
            // 
            this.btnPantColor.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.btnPantColor.Font = new System.Drawing.Font("Microsoft YaHei", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPantColor.Location = new System.Drawing.Point(662, 119);
            this.btnPantColor.Name = "btnPantColor";
            this.btnPantColor.Size = new System.Drawing.Size(128, 51);
            this.btnPantColor.TabIndex = 2;
            this.btnPantColor.Text = "Pant Color";
            this.btnPantColor.UseVisualStyleBackColor = false;
            this.btnPantColor.Click += new System.EventHandler(this.btnSkirtColor_Click);
            // 
            // comboFacewear
            // 
            this.comboFacewear.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboFacewear.FormattingEnabled = true;
            this.comboFacewear.Items.AddRange(new object[] {
            "None",
            "Sun Glasses",
            "Glasses",
            "Hockey Mask",
            "No-facewear",
            "Ski Mask",
            "Cap"});
            this.comboFacewear.Location = new System.Drawing.Point(5, 36);
            this.comboFacewear.Name = "comboFacewear";
            this.comboFacewear.Size = new System.Drawing.Size(189, 28);
            this.comboFacewear.TabIndex = 3;
            this.comboFacewear.SelectedIndexChanged += new System.EventHandler(this.comboFacewear_SelectedIndexChanged);
            // 
            // btnDeleteRhinestones
            // 
            this.btnDeleteRhinestones.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.btnDeleteRhinestones.Font = new System.Drawing.Font("Microsoft YaHei", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDeleteRhinestones.Location = new System.Drawing.Point(662, 199);
            this.btnDeleteRhinestones.Name = "btnDeleteRhinestones";
            this.btnDeleteRhinestones.Size = new System.Drawing.Size(128, 51);
            this.btnDeleteRhinestones.TabIndex = 4;
            this.btnDeleteRhinestones.Text = "Delete Sparkle";
            this.btnDeleteRhinestones.UseVisualStyleBackColor = false;
            this.btnDeleteRhinestones.Click += new System.EventHandler(this.btnDeleteRhinestones_Click_1);
            // 
            // btnsunglasses
            // 
            this.btnsunglasses.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.btnsunglasses.Font = new System.Drawing.Font("Microsoft YaHei", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnsunglasses.Location = new System.Drawing.Point(72, 83);
            this.btnsunglasses.Name = "btnsunglasses";
            this.btnsunglasses.Size = new System.Drawing.Size(107, 51);
            this.btnsunglasses.TabIndex = 6;
            this.btnsunglasses.Text = "Sun Glasses";
            this.btnsunglasses.UseVisualStyleBackColor = false;
            this.btnsunglasses.Click += new System.EventHandler(this.btnsunglasses_Click);
            // 
            // btnglasses
            // 
            this.btnglasses.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.btnglasses.Font = new System.Drawing.Font("Microsoft YaHei", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnglasses.Location = new System.Drawing.Point(72, 140);
            this.btnglasses.Name = "btnglasses";
            this.btnglasses.Size = new System.Drawing.Size(107, 51);
            this.btnglasses.TabIndex = 7;
            this.btnglasses.Text = "Glasses";
            this.btnglasses.UseVisualStyleBackColor = false;
            this.btnglasses.Click += new System.EventHandler(this.btnglasses_Click);
            // 
            // btnfacewear
            // 
            this.btnfacewear.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.btnfacewear.Font = new System.Drawing.Font("Microsoft YaHei", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnfacewear.Location = new System.Drawing.Point(72, 254);
            this.btnfacewear.Name = "btnfacewear";
            this.btnfacewear.Size = new System.Drawing.Size(107, 51);
            this.btnfacewear.TabIndex = 9;
            this.btnfacewear.Text = "facewear (Mask)";
            this.btnfacewear.UseVisualStyleBackColor = false;
            this.btnfacewear.Click += new System.EventHandler(this.btnfacewear_Click);
            // 
            // btnhockymask
            // 
            this.btnhockymask.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.btnhockymask.Font = new System.Drawing.Font("Microsoft YaHei", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnhockymask.Location = new System.Drawing.Point(72, 197);
            this.btnhockymask.Name = "btnhockymask";
            this.btnhockymask.Size = new System.Drawing.Size(107, 51);
            this.btnhockymask.TabIndex = 8;
            this.btnhockymask.Text = "Hocky Mask";
            this.btnhockymask.UseVisualStyleBackColor = false;
            this.btnhockymask.Click += new System.EventHandler(this.btnhockymask_Click);
            // 
            // btncap
            // 
            this.btncap.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.btncap.Font = new System.Drawing.Font("Microsoft YaHei", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btncap.Location = new System.Drawing.Point(72, 368);
            this.btncap.Name = "btncap";
            this.btncap.Size = new System.Drawing.Size(107, 51);
            this.btncap.TabIndex = 11;
            this.btncap.Text = "Cap";
            this.btncap.UseVisualStyleBackColor = false;
            this.btncap.Click += new System.EventHandler(this.btncap_Click);
            // 
            // btnskimask
            // 
            this.btnskimask.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.btnskimask.Font = new System.Drawing.Font("Microsoft YaHei", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnskimask.Location = new System.Drawing.Point(72, 311);
            this.btnskimask.Name = "btnskimask";
            this.btnskimask.Size = new System.Drawing.Size(107, 51);
            this.btnskimask.TabIndex = 10;
            this.btnskimask.Text = "Ski Mask";
            this.btnskimask.UseVisualStyleBackColor = false;
            this.btnskimask.Click += new System.EventHandler(this.btnskimask_Click);
            // 
            // btnnone
            // 
            this.btnnone.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.btnnone.Font = new System.Drawing.Font("Microsoft YaHei", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnnone.Location = new System.Drawing.Point(72, 425);
            this.btnnone.Name = "btnnone";
            this.btnnone.Size = new System.Drawing.Size(107, 51);
            this.btnnone.TabIndex = 12;
            this.btnnone.Text = "None";
            this.btnnone.UseVisualStyleBackColor = false;
            this.btnnone.Click += new System.EventHandler(this.btnnone_Click);
            // 
            // pictureBox10
            // 
            this.pictureBox10.Image = global::Doll_Managment_Project.Properties.Resources.no_entry;
            this.pictureBox10.Location = new System.Drawing.Point(5, 425);
            this.pictureBox10.Name = "pictureBox10";
            this.pictureBox10.Size = new System.Drawing.Size(61, 51);
            this.pictureBox10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox10.TabIndex = 22;
            this.pictureBox10.TabStop = false;
            // 
            // pictureBox8
            // 
            this.pictureBox8.Image = global::Doll_Managment_Project.Properties.Resources.mycap;
            this.pictureBox8.Location = new System.Drawing.Point(5, 368);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(61, 51);
            this.pictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox8.TabIndex = 21;
            this.pictureBox8.TabStop = false;
            // 
            // pictureBox9
            // 
            this.pictureBox9.Image = global::Doll_Managment_Project.Properties.Resources.ski_mask;
            this.pictureBox9.Location = new System.Drawing.Point(5, 311);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(61, 51);
            this.pictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox9.TabIndex = 20;
            this.pictureBox9.TabStop = false;
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = global::Doll_Managment_Project.Properties.Resources.no_facewear;
            this.pictureBox6.Location = new System.Drawing.Point(5, 254);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(61, 51);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox6.TabIndex = 19;
            this.pictureBox6.TabStop = false;
            // 
            // pictureBox7
            // 
            this.pictureBox7.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox7.Image")));
            this.pictureBox7.Location = new System.Drawing.Point(5, 197);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(61, 51);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox7.TabIndex = 18;
            this.pictureBox7.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = global::Doll_Managment_Project.Properties.Resources.newglass;
            this.pictureBox5.Location = new System.Drawing.Point(5, 140);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(61, 51);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox5.TabIndex = 17;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::Doll_Managment_Project.Properties.Resources.sunglasses;
            this.pictureBox4.Location = new System.Drawing.Point(5, 83);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(61, 51);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 16;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::Doll_Managment_Project.Properties.Resources.cancel;
            this.pictureBox3.Location = new System.Drawing.Point(796, 199);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(58, 51);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 15;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::Doll_Managment_Project.Properties.Resources.pant;
            this.pictureBox2.Location = new System.Drawing.Point(796, 119);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(58, 51);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 14;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Doll_Managment_Project.Properties.Resources.shirt;
            this.pictureBox1.Location = new System.Drawing.Point(796, 40);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(58, 50);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 13;
            this.pictureBox1.TabStop = false;
            // 
            // btnexit
            // 
            this.btnexit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.btnexit.Font = new System.Drawing.Font("Microsoft YaHei", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnexit.Location = new System.Drawing.Point(662, 440);
            this.btnexit.Name = "btnexit";
            this.btnexit.Size = new System.Drawing.Size(128, 50);
            this.btnexit.TabIndex = 5;
            this.btnexit.Text = "Exit";
            this.btnexit.UseVisualStyleBackColor = false;
            this.btnexit.Click += new System.EventHandler(this.btnexit_Click);
            // 
            // pictureBox
            // 
            this.pictureBox.BackColor = System.Drawing.Color.White;
            this.pictureBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox.Location = new System.Drawing.Point(201, 12);
            this.pictureBox.Name = "pictureBox";
            this.pictureBox.Size = new System.Drawing.Size(440, 480);
            this.pictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox.TabIndex = 0;
            this.pictureBox.TabStop = false;
            this.pictureBox.MouseClick += new System.Windows.Forms.MouseEventHandler(this.pictureBox_MouseClick);
            this.pictureBox.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pictureBox_MouseMove);
            // 
            // pictureBox11
            // 
            this.pictureBox11.Image = global::Doll_Managment_Project.Properties.Resources.exit;
            this.pictureBox11.Location = new System.Drawing.Point(796, 439);
            this.pictureBox11.Name = "pictureBox11";
            this.pictureBox11.Size = new System.Drawing.Size(58, 51);
            this.pictureBox11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox11.TabIndex = 23;
            this.pictureBox11.TabStop = false;
            // 
            // cmboSparkle
            // 
            this.cmboSparkle.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmboSparkle.FormattingEnabled = true;
            this.cmboSparkle.Items.AddRange(new object[] {
            "Diamond",
            "Circle",
            "Heart"});
            this.cmboSparkle.Location = new System.Drawing.Point(651, 328);
            this.cmboSparkle.Name = "cmboSparkle";
            this.cmboSparkle.Size = new System.Drawing.Size(203, 28);
            this.cmboSparkle.TabIndex = 24;
            this.cmboSparkle.SelectedIndexChanged += new System.EventHandler(this.cmboSparkle_SelectedIndexChanged_1);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(1, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(103, 24);
            this.label1.TabIndex = 25;
            this.label1.Text = "Facewears";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(647, 300);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(130, 24);
            this.label2.TabIndex = 26;
            this.label2.Text = "Sparkle Types";
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.ClientSize = new System.Drawing.Size(859, 498);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.cmboSparkle);
            this.Controls.Add(this.pictureBox11);
            this.Controls.Add(this.pictureBox10);
            this.Controls.Add(this.pictureBox8);
            this.Controls.Add(this.pictureBox9);
            this.Controls.Add(this.pictureBox6);
            this.Controls.Add(this.pictureBox7);
            this.Controls.Add(this.pictureBox5);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.btnnone);
            this.Controls.Add(this.btncap);
            this.Controls.Add(this.btnskimask);
            this.Controls.Add(this.btnfacewear);
            this.Controls.Add(this.btnhockymask);
            this.Controls.Add(this.btnglasses);
            this.Controls.Add(this.btnsunglasses);
            this.Controls.Add(this.btnexit);
            this.Controls.Add(this.btnDeleteRhinestones);
            this.Controls.Add(this.comboFacewear);
            this.Controls.Add(this.btnPantColor);
            this.Controls.Add(this.btnShirtColor);
            this.Controls.Add(this.pictureBox);
            this.MaximizeBox = false;
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Doll System";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox;
        private System.Windows.Forms.Button btnShirtColor;
        private System.Windows.Forms.Button btnPantColor;
        private System.Windows.Forms.ComboBox comboFacewear;
        private System.Windows.Forms.ColorDialog colorDialog;
        private System.Windows.Forms.Button btnDeleteRhinestones;
        private System.Windows.Forms.Button btnexit;
        private System.Windows.Forms.Button btnsunglasses;
        private System.Windows.Forms.Button btnglasses;
        private System.Windows.Forms.Button btnfacewear;
        private System.Windows.Forms.Button btnhockymask;
        private System.Windows.Forms.Button btncap;
        private System.Windows.Forms.Button btnskimask;
        private System.Windows.Forms.Button btnnone;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.PictureBox pictureBox10;
        private System.Windows.Forms.PictureBox pictureBox11;
        private System.Windows.Forms.ComboBox cmboSparkle;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
    }
}

